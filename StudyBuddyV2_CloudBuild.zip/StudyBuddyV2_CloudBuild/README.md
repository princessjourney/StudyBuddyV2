# Study Buddy V2

Prototype Android untuk teman belajar pribadi.

Fitur V2:
- Beranda dengan XP dan streak
- Study Buddy/tutor virtual
- Materi Bahasa Indonesia, Seni Budaya, dan TKJ
- Sesi belajar per materi
- Quiz/game pembelajaran
- Jadwal belajar
- Simulasi panggilan tutor
- Fondasi untuk TTS, notifikasi, video, database, dan AI chat

Catatan:
- Tutor adalah karakter virtual/fiksi, bukan representasi orang nyata.
- Suara sintetis/orisinal dapat ditambahkan pada tahap berikutnya.
- Buka proyek di Android Studio lalu Build > Build APK(s).


## Build APK tanpa laptop
Folder `.github/workflows/build-apk.yml` sudah disiapkan untuk GitHub Actions.
Setelah project di-upload ke repository GitHub, buka tab Actions dan jalankan
workflow "Build Study Buddy APK". Jika berhasil, APK dapat diunduh dari bagian
Artifacts pada hasil workflow.
