package com.studybuddy.v2

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var xp = 120
    private var streak = 7
    private val navy = Color.rgb(35,45,75)
    private val purple = Color.rgb(115,92,220)
    private val bg = Color.rgb(247,249,252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(24, 28, 24, 12)

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this)
        nav.gravity = Gravity.CENTER
        nav.setPadding(0, 10, 0, 0)
        nav.addView(navBtn("⌂\nBeranda") { showHome() })
        nav.addView(navBtn("📚\nMateri") { showMaterials() })
        nav.addView(navBtn("🎮\nGame") { showGame() })
        nav.addView(navBtn("⏰\nJadwal") { showSchedule() })
        root.addView(nav, LinearLayout.LayoutParams(-1, 70))
        return root
    }

    private fun navBtn(text: String, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 11f
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, 65, 1f)
        }
    }

    private fun title(t: String, size: Float = 27f): TextView =
        TextView(this).apply { text=t; textSize=size; setTextColor(navy); setPadding(0,0,0,14) }

    private fun card(t: String, sub: String, action: (() -> Unit)? = null): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(22,18,22,18)
        box.setBackgroundColor(Color.WHITE)
        box.elevation = 3f
        val a = TextView(this).apply { text=t; textSize=18f; setTextColor(navy) }
        val b = TextView(this).apply { text=sub; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,8,0,0) }
        box.addView(a); box.addView(b)
        if (action != null) box.setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, -2); p.setMargins(0,8,0,8)
        box.layoutParams=p
        return box
    }

    private fun primary(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text=text; textSize=16f; setTextColor(Color.WHITE)
            setBackgroundColor(purple); setOnClickListener { action() }
            layoutParams=LinearLayout.LayoutParams(-1,58).apply { setMargins(0,12,0,12) }
        }

    private fun showHome() {
        setContentView(base())
        content.addView(title("Hai! 👋\nWaktunya belajar?"))
        content.addView(TextView(this).apply {
            text="Study Buddy siap menemani kamu hari ini."
            textSize=16f; setTextColor(Color.DKGRAY)
        })
        content.addView(card("🔥  Streak $streak hari", "Pertahankan kebiasaan belajarmu hari ini!"))
        content.addView(card("⭐  XP $xp", "Naikkan XP dengan menyelesaikan materi dan game."))
        content.addView(primary("🚀 Mulai Belajar", { showTutor() }))
        content.addView(card("📚 Materi minggu ini", "Bahasa Indonesia • Seni Budaya • TKJ", { showMaterials() }))
        content.addView(card("⏰ Jadwal berikutnya", "16:00 — Sesi belajar 30 menit", { showSchedule() }))
    }

    private fun showTutor() {
        setContentView(base())
        content.addView(title("🤖 Study Buddy"))
        content.addView(card("AI Study Buddy", "Karakter virtual yang menemani belajar. Pilih materi, lalu mulai sesi."))
        content.addView(card("💬 Tutor", "“Kita belajar pelan-pelan ya. Kalau bingung, bilang saja.”"))
        content.addView(primary("📖 Mulai sesi Bahasa Indonesia") { showLesson("Bahasa Indonesia — Teks LHO") })
        content.addView(primary("🖥️ Mulai sesi TKJ") { showLesson("TKJ — Sistem Komputer") })
        content.addView(primary("🎙️ Dengarkan tutor (demo)") {
            Toast.makeText(this, "Demo suara: fitur TTS akan dihubungkan di tahap berikutnya.", Toast.LENGTH_LONG).show()
        })
    }

    private fun showMaterials() {
        setContentView(base())
        content.addView(title("📚 Materi Belajar"))
        content.addView(card("Bahasa Indonesia", "Teks LHO • Anekdot", { showLesson("Bahasa Indonesia — Teks LHO") }))
        content.addView(card("Seni Budaya", "Pengertian & unsur seni rupa", { showLesson("Seni Budaya — Seni Rupa") }))
        content.addView(card("TKJ", "Sistem komputer • hardware • software • brainware", { showLesson("TKJ — Sistem Komputer") }))
    }

    private fun showLesson(name: String) {
        setContentView(base())
        content.addView(title(name, 23f))
        val text = when {
            name.contains("LHO") -> "Teks LHO adalah teks yang menyampaikan hasil pengamatan terhadap suatu objek secara objektif. Struktur umumnya meliputi pernyataan umum dan deskripsi bagian."
            name.contains("Seni") -> "Seni rupa adalah karya seni yang dapat dinikmati melalui indera penglihatan dan/atau peraba. Unsurnya antara lain titik, garis, bidang, bentuk, warna, tekstur, dan ruang."
            else -> "Sistem komputer adalah sistem yang digunakan untuk mengolah data menjadi informasi. Komponennya meliputi hardware, software, dan brainware."
        }
        content.addView(card("🧠 Penjelasan", text))
        content.addView(card("💡 Tips Tutor", "Baca bagian penting, tutup materi, lalu coba jelaskan kembali dengan kata-katamu sendiri."))
        content.addView(primary("🎮 Uji pemahaman", { showGame() }))
        content.addView(primary("✅ Tandai selesai", {
            xp += 20
            Toast.makeText(this, "+20 XP! Materi selesai.", Toast.LENGTH_SHORT).show()
            showHome()
        }))
    }

    private fun showGame() {
        setContentView(base())
        content.addView(title("🎮 Game Belajar"))
        content.addView(card("Quiz cepat", "Jawab pertanyaan dan dapatkan XP!"))
        val q = TextView(this).apply {
            text="Apa saja tiga komponen utama sistem komputer?"
            textSize=18f; setTextColor(navy); setPadding(0,15,0,10)
        }
        content.addView(q)
        val opts = listOf("Hardware, software, brainware", "Monitor, meja, buku", "Internet, listrik, meja")
        opts.forEach { opt ->
            content.addView(primary(opt) {
                if (opt.startsWith("Hardware")) {
                    xp += 30
                    Toast.makeText(this, "Benar! +30 XP 🎉", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Belum tepat. Coba lagi!", Toast.LENGTH_SHORT).show()
            })
        }
        content.addView(card("⭐ XP sekarang", "$xp XP"))
    }

    private fun showSchedule() {
        setContentView(base())
        content.addView(title("⏰ Jadwal Belajar"))
        content.addView(card("16:00", "Bahasa Indonesia — 30 menit"))
        content.addView(card("19:30", "TKJ — 30 menit"))
        content.addView(primary("📞 Simulasikan panggilan tutor") {
            AlertDialog.Builder(this)
                .setTitle("📞 Study Buddy memanggil...")
                .setMessage("“Hei! Waktunya belajar. Angkat sekarang?”")
                .setPositiveButton("Angkat") { _, _ -> showTutor() }
                .setNegativeButton("Tunda", null)
                .show()
        })
        content.addView(card("🔔 Notifikasi", "Versi berikutnya dapat menjadwalkan notifikasi otomatis sesuai jam belajar."))
    }
}
